# @clashking/clash-contract

Version 0.1.2. MockAPI's Pydantic response models and route declarations are the
source of truth for this community-maintained Clash of Clans wire contract.
This package is generated from the same OpenAPI 3.1 schema served by MockAPI.
It does not define ClashKing application responses or claim official Supercell ownership.

## Generate and validate

From the repository root (Python 3.13.7+, uv, Node 22+):

```sh
uv sync --frozen
npm ci --prefix packages/clash-contract
npm run generate --prefix packages/clash-contract
uv run python -m unittest discover -s tests
npm run check:generated --prefix packages/clash-contract
npm test --prefix packages/clash-contract
npm pack ./packages/clash-contract
```

Commit the exported OpenAPI, generated sources, generator, and lockfiles together.
`check:generated` compares a fresh export and generation in a temporary directory;
it fails without modifying the checkout. Set `PYTHON` to a Python executable if
not using the repository's `.venv`. Build output is ignored and recreated by
`npm run build` and `npm pack`. No publishing is part of this workflow.

`openapi.json` uses a stable server URL and the package version, independent of
`MOCK_PROXY_URL`. Exported paths and components match `main.app.openapi()`.
`src/schema.ts` comes from openapi-typescript; `src/validators.js` contains AJV
standalone validators; `src/effect.ts` contains native Effect structures generated
from those same components. The Effect generator fails on unsupported schema
keywords rather than silently discarding new constraints.

## Consume without copying wire schemas

The unpublished package can be transferred as a tarball and vendored relative to
the consuming repository, so installs work on developer machines and CI:

```sh
npm install ./vendor/clashking-clash-contract-0.1.2.tgz
```

Commit that tarball and the consumer's package lock. This records a portable
`file:vendor/clashking-clash-contract-0.1.2.tgz` dependency and integrity hash.
After an explicitly authorized future registry release, use the exact dependency
`"@clashking/clash-contract": "0.1.2"` instead. No registry publication has occurred.

```ts
import { parse, validators, type Schemas } from '@clashking/clash-contract';
const clan = parse('Clan', await response.json());
// clan is Schemas['Clan']; invalid input throws TypeError with validation errors.
if (validators.Clan(payload)) console.log(payload.clanCapital.clanGoldSinkTotal);
```

The root export has no runtime dependencies and requires no runtime compilation,
network, Python, or dynamic code evaluation. It preserves the original payload,
allows unknown fields, and does not coerce values or insert defaults.
Optional means absent; nullable means JSON null. JSON Schema formats are metadata,
not additional validation (currently only int64). JavaScript numbers cannot retain
integers beyond Number.MAX_SAFE_INTEGER exactly; int64 does not promise bigint or
lossless parsing. Callers needing that must handle the raw JSON before decoding.

## Effect 4 composition

Install the consumer's exact `effect@4.0.0-rc.112` version to use the optional
`@clashking/clash-contract/effect` export. This is an exact optional peer because
Effect prerelease schema APIs may change. The root validator export needs no Effect.

```ts
import { Schema } from 'effect';
import { Clan, WarClan, ClanWar } from '@clashking/clash-contract/effect';
const ClanWithLocalId = Schema.Struct({ ...Clan.fields, localId: Schema.String });
const WarSummary = Schema.Struct({
  state: ClanWar.fields.state,
  clanName: WarClan.fields.name,
  capital: Clan.fields.clanCapital,
});
// Direct nested object refs remain structs: Clan.fields.clanCapital.fields exists.
const gold = Clan.fields.clanCapital.fields.clanGoldSinkTotal;
const decoded = Schema.decodeUnknownSync(ClanWithLocalId)(payload, {
  onExcessProperty: 'preserve',
});
```

All named object components expose `.fields`; nested references use those actual
structures. Optional/nullable fields retain their Effect wrappers. Import the
named component (for example `WarClan`) when composing fields inside a union.
Recursive item references use `Schema.suspend`. Effect uses readonly inferred
values and by default removes excess object properties; pass
`onExcessProperty: 'preserve'` when wire payload preservation is needed.

Use these imports in the API's existing local compositions and keep only its
application-specific fields there. No consumer repository was modified here.

## Contract changes and downstream impact

Bump the package version whenever the exported contract changes; use a new minor
version for breaking changes while below 1.0, and patch releases for compatible
fixes. Regenerate and validate every fixture through both AJV and Effect before
releasing. Never hand-edit generated files or duplicate wire fields in consumers.

The first full fixture check corrected existing model mismatches: error `message`
and war-participant `tag`/`name` may be absent. Completed-season rankings now use a
separate model with optional `previousRank`; live rankings still require it.
No fixture data or response handler behavior changed.

- `cocpy` can stay unchanged for these corrections: its dictionary-based parsers
  already tolerate missing identity/rank fields. A separate fix is needed for
  the existing no-districts fixture: its clan parser indexes `clanCapital["districts"]`
  and should use `.get("districts", [])`. Its clan model also does not expose `clanGoldSinkTotal`; adding a public property is a recommended,
  separate parity improvement for a field that already existed in MockAPI.
- `clashy.go` can stay unchanged for these corrections: omitted fields decode to
  Go zero values. Its `ClanCapital` currently only exposes districts; adding an
  int64 gold-total field is likewise a separate parity improvement, not required
  to consume this TypeScript package. Neither sibling repository was edited.

### Optional arrays and service requirements

`ClanWarLeagueGroup.fields.clans` is an optional-property wrapper, so do not
extract its item through `.value`. Import the named item struct directly and
rebuild the wrapper if the consumer extends the item:

```ts
import { Schema } from 'effect';
import { ClanWarLeagueClan, ClanWarLeagueGroup, Player } from '@clashking/clash-contract/effect';
const ExtendedClan = Schema.Struct({ ...ClanWarLeagueClan.fields, localId: Schema.String });
const ExtendedGroup = Schema.Struct({
  ...ClanWarLeagueGroup.fields,
  clans: Schema.optionalKey(Schema.Array(ExtendedClan)),
});
const playerContract: Schema.Codec<unknown, unknown, never, never> =
  Schema.Struct({ player: Player });
```

Every exported wire schema requires `never` decoding and encoding services.
Compile-time tests check every export, a containing Player struct, and recursive
item types through the emitted declarations. Recursive schemas use named wire
interfaces and explicit service-free codecs to prevent declaration emission from
expanding recursive types into `any`. Rebuild and reinstall the tarball after
local changes; an already installed package does not follow source edits.

Downstream-tested wire variants are covered explicitly: `Player.leagueTier` may
be absent (a present value must still be a league object), and clanless
`LeagueGroupMember` entries retain required `clanTag` and `clanName` keys with
JSON null values. The original fixtures did not contain these variants; tests
construct them from complete fixtures. `cocpy` already uses tolerant dictionary
lookups for these fields, and Go JSON decoding accepts null string fields as
zero values, so neither downstream library needs a change for these variants.

Treat packed versions as immutable: any change to tarball contents requires a new
version before handing the artifact to a consumer. Version 0.1.2 includes the
optional player league tier and nullable clanless league-member identity variants.

Version 0.1.2 accepts fractional `ClanWarAttack.destructionPercentage` values.
`WarClan.destructionPercentage` already accepted fractions. Player and league
battle-log percentages and capital `destructionPercent` fields remain unchanged;
no authoritative evidence was available here to broaden those distinct fields.
